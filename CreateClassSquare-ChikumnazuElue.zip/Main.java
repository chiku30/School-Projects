class Main {
  public static void main(String[] args) {
    Square sqr = new Square(20);
    System.out.println(sqr.getSide());
    System.out.println(sqr.getArea());
    sqr.setSide(10);
    System.out.println(sqr.getArea());
    sqr.setSide(-5);
    System.out.println(sqr.getArea());
    System.out.println(sqr.getDiagonal());

    Square sqr2 = new Square();
    Square sqr3 = new Square();
    System.out.println(sqr2.toString());
    System.out.println(sqr2.compareTo(sqr3));
    sqr2.dilate(5);
    sqr2.dilate(7);
    System.out.println(sqr2.toString());
    System.out.println(sqr2.compareTo(sqr3));
    System.out.println(sqr3.compareTo(sqr2));

  }
}