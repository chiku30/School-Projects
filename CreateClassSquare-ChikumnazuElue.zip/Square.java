public class Square {

  // instance varibles
  private int side;

  // constructors
  public Square(int sideP) {
    side = sideP;

  }

  public Square() {
    side = 1;
  }

  // methods
  public int getSide() {
    return side;
  }

  public void setSide(int sideP) {
    
    if (sideP > 0 ) {
      side = sideP;
    }
  }

  // methods
  public int getArea() {
    return side * side;
  }

  //method
  public double getDiagonal() {
    return Math.sqrt(side * side + side * side);
  }

  //method Question 2
  public String toString() {
    return "Sqaure with side" + " " + side;
  }

  //method
  public void dilate(int scaleFactor) {
    side = side * scaleFactor;
  }

  //method
  public int compareTo(Square other) {
    if(side < other.getSide()) {
      return -1;
    }
    else if(side > other.getSide()) {
      return 1;
    } else 
    {
      return 0;
    }
  }

}