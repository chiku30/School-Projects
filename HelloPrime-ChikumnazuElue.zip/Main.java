
/**
 * HelloPrime is an algorithm efficiency task.. a timed challenge.. see how
 * fast you can get your algorithm to count the number of primes from 2 to
 * 150000
 */

public class Main {

  public static void main(String[] args) {
    // maximum is 250000
    int upperBound = 250000;
    System.out.println("Determining the number of primes between 2 and " + upperBound + "...");
    System.out.print("\nThis may take a few seconds...");
    long curTime = System.currentTimeMillis();
    int numPrimes = 1; // presume 2 is prime
    
    for (int k = 2; k <= upperBound; k++) {
      if (isPrime(k)) {
        numPrimes++;
      }
      if (k % 10000 == 0) {
        System.out.print(".");
      }
    }

    System.out.println("\n\n" + numPrimes + " primes from 2 to " + upperBound);
    double elapsedTime = (System.currentTimeMillis() - curTime) / 1000.0;
    System.out.println("It took " + elapsedTime + " seconds\n");

  }

  /**
   * return true if n is prime, false otherwise (precondition: n >= 2)
   */

  public static boolean isPrime(int n) {

       for(int i = 2; i * i < n; i++) {
      if(n % i == 0) {
        return false;
      }
  }
   
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    // YOUR CODE GOES HERE..
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    // place the code here you wrote in Codingbat
    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    return true;
  }
}
