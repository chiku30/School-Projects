import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    
    Scanner console = new Scanner(System.in);
    System.out.println("Input a radius .");

    //declare a variable called r for the radius
    double r;
    //read r from the user
    //r = console.nextDouble();
    r = console.nextDouble();
    //create a constant called pi and assign it 3.14
    final double pi = 3.14;
    //create a variable called volume and 
    double volume;
    //  assign it the volume of the sphere
    
    //  (look up formula for volume)
    volume = (4.0/3.0 * pi) * (r * r * r); 

  
    //print the volume of the sphere as a complete sentence
    System.out.println(volume); 
    //Example sentence:
    //The volume of a sphere with radius 1.0 is 4.18879

    boolean startOver;
    boolean doNotStartOver;


  }
}