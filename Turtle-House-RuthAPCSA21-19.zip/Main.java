import javax.swing.*;
import java.awt.event.*;
import java.util.*;
import java.awt.*;

public class Main {
  public static void main(String[] args) {  
    World world = new World(300,300);
    
    //1. declare and initialzie a new Turtle Object called crush
    Turtle crush = new Turtle(170, 200, world);

    //2. move crush to your starting point of your house
    crush.turnLeft();
    crush.forward();

    //3. write all the code have crush draw the 
    //   eight segments of the house diagram
    //   without using penUp() and without 
    //   redrawing any segments
    
    crush.turnRight();
    crush.forward();
    crush.turn(-90);
    crush.turn(225);
    crush.forward(141);
    crush.turn(225);
    crush.forward();
    // Building the roof
    crush.turn(-45);
    crush.forward(71);
    crush.turn(-90);
    crush.forward(71);
    crush.turn(-135.5);
    crush.forward();
    crush.turn(-90);
    crush.turn(-135.5);
    crush.forward(141);

   
      //crush.turnLeft();
      //crush.forward();
      //crush.turn(135);
      //crush.forward(71);
      //crush.turnRight();
      //crush.forward(71);
      //crush.turn(135);
      //crush.turn(-45);
      //crush.forward(141);


    crush.hide();
    world.setVisible(true);
  }
}
