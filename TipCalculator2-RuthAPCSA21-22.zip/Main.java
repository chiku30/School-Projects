import java.util.Scanner;
/*
This program will allow the user to type in the
amount of a meal as a double and a tip rate 
as an integer percent and output the dollar amount 
of the tip and the total amount to be paid.
 
 
Here is one example of how the program should look when it is run:
(note: when you click the run> button... 
you will have to type 24.55, hit enter, type 20, hit enter)
 
Calculate the tip for a meal.
Please enter the price of the meal: 24.55
Please enter the tip rate as a percent: 20
meal:   24.55
tip:    4.91
--------------------
total:  29.46
*/


//Fill in each line 'YOUR CODE GOES HERE' with your own code
//so the program works as expected

class Main {
  public static void main(String[] args) {
    System.out.println("Calculate the tip for a meal.");
    Scanner console = new Scanner(System.in);

    //declare a variable mealAmount
    double mealAmount;

    //read mealPrice from the console
    System.out.print("Please enter the price of the meal: ");
    mealAmount = console.nextDouble();

    //declare a variable called tipRate as a percent
    //YOUR CODE GOES HERE
    double tipRate;
    
    
    //read the value of the tipRate from the console
    //YOUR CODE GOES HERE
    System.out.print("How much would you like to tip?");
    tipRate = console.nextDouble();

  
    //delare and initialize a variable called tipAmount ( tipRate as a decimal times mealPrice )
    //YOUR CODE GOES HERE
    double tipAmount;
    tipAmount = (tipRate * .01) * mealAmount;

    //output the amount of the meal 
    System.out.println("Meal:\t" + "$" + mealAmount);

    //output the amount of tip 
    //YOUR CODE GOES HERE
    System.out.println("Tip:\t" + "$" + tipAmount);

    System.out.println("--------------------");
    //output the total amount to pay ( mealAmount plus tipAmount)
    //YOUR CODE GOES HERE
    double priceTotal;
    priceTotal = mealAmount + tipAmount;
    System.out.print("Total:\t" + "$" + priceTotal);
  }
}