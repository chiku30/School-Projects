
class Main {

  private static int numTrials = 100000;
  private static int numSuccessfulTrials = 0;

  /**
   * assign a random integer from 1 to 365 inclusive to each element in nums
   */
  public static void fillWithRandomFrom1to365(int nums[]) {

    // YOUR CODE GOES HERE
 // 
    for (int i = 0; i < nums.length; i++) {
      int randomNumber = (int) (Math.random() * 365) + 1;
      
      nums[i] = randomNumber;
    }

  }

  /**
   * return true if any two values in nums are equal.. false otherwise copy your
   * code appropriately from your Codingbat problem
   */
  public static boolean hasDuplicates(int nums[]) {

    // YOUR CODE GOES HERE
    for (int i = 0; i < nums.length; i++) {
      for (int count = i + 1; count < nums.length; count++) {
        if (nums[i] == nums[count]) {
          return true;
        }
      }
    }
    return false;
  }

  /**
   * DO NOT MODIFY THIS METHOD!
   */
  public static void main(String[] args) {

    System.out.println("Birthday Problem!");
    System.out.println(
        "What is the probability that two students " + "in a class of 30\nshare the same birthday (month & day only)?");
    int numStudents = 30;
    int birthdays[] = new int[numStudents];
    for (int trial = 1; trial <= numTrials; trial++) {
      fillWithRandomFrom1to365(birthdays);
      if (hasDuplicates(birthdays)) {
        numSuccessfulTrials++;
      }
    }
    double prob = (int) (1000.0 * numSuccessfulTrials / numTrials + 0.5) / 10.0;
    System.out.print("\nThe probability is " + prob + "%");
  }

}