# Java

This is the Template Repl for Java.

Java is a concurrent, class-based, statically typed object-oriented language.

[Check out the official docs here](https://docs.oracle.com/javase/8/docs/api/).