import java.util.Scanner;
/*
The Game of Chi begins with a random number of stones in a pile
in between two players. Each player take turns drawing their choice
of either 1,2 or 3 stones from the pile.
The player who draws the last stone loses.

In this version, the user is player 1 and the computer is player two.
*/

class Main {
  public static void main(String[] args) {
    System.out.println("This is the Game of Chi");
    Scanner console = new Scanner(System.in);
    // 1. assign variable numStones a random number from 20 to 30
    // Our random number goes to 28.
    int numStones = (int) (Math.random() * 11) + 20;
    int drawStones = 0;
    System.out.println("There are currently " + numStones + " stones.");
    while (true) {
      // 2. print the current number of stones in the pile

      // 3. write a while loop that executes the following:
      // - ask (print) player 1 to draw 1,2 or 3 stones
      // - assign console.nextInt() to drawStones
      // the loop will continue while drawStones is a valid integer
      // .. here valid means it is either a 1, 2 or 3 and
      // is less than or equal to numStones

      drawStones = console.nextInt();
      if (drawStones > 0 && drawStones <= 3 && numStones - drawStones >= 0) {

        // 4. subtract drawStones from numStones

        numStones = numStones - drawStones;

        // 6. print the current number of stones in the pile
        System.out.println("There are currently " + numStones + " stones.");
        // 9. try to figure out what should go here..
        // (hint: it is similar to step 5)
        if (numStones <= 0) {
          System.out.println("CPU wins!");
          break;
        }
        // 7. the CPU will choose a random number from 1 to 3 inclusive
        int CPUDraws = (int) (Math.random() * 3) + 1;
        // Redrawing CPUDraws until it's not a number that'll make numStones negative
        // unless there are less than 3 stones in the pile...
        // in that case it will choose a random number from 1 to numStones
        while (numStones - CPUDraws < 0) {
          CPUDraws = (int) (Math.random() * numStones) + 1;
        }
        // 8. print how many stones the CPU draws
        System.out.println("CPU Chooses" + " " + CPUDraws);

        numStones = numStones - CPUDraws;
        System.out.println("There are currently " + numStones + " stones.");
        // 5. if numStones is zero.. print "CPU wins!" and break the loop
        if (numStones <= 0) {
          System.out.println("Player wins!");
          break;
        }
      } else if (drawStones < 0) {
        System.out.println("Too Low!");
      } else if (drawStones > 3 || numStones - drawStones < 0) {
        System.out.println("Too High!");
      }
        
        // EXTRA CREDIT .. have the CPU play with a winning strategy
        // instead of choosing randomly
        while(numStones == 5) {
          if(drawStones == 1) {
            CPUDraws = 1;
          }
        }
    }

  }
}

