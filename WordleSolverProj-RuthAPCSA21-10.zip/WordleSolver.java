import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class WordleSolver {

  private ArrayList<String> wordList;

  // Part A ... Part A
  // Remove words from wordList according to Gray letter rules
  // Precondition: letters.length() <= 5 and
  // letters only contains uppercase letters
  public void removeWordsGrayLetters(String letters) {

    // YOUR CODE GOES HERE
    for (int i = 0; i < letters.length(); i++) {
      String ithLetter = letters.substring(i, i + 1);
      for (int j = 0; j < wordList.size(); j++) {
        if (wordList.get(j).indexOf(ithLetter) != -1) {
          wordList.remove(j);
          j--;
        }
      }
    }
  }

  // Part B ... Part B
  // Remove words from wordList according to Yellow letter rules
  // Precondition: letters.length() == 5 and
  // letters only contains uppercase letters and '.'
  public void removeWordsYellowLetters(String letters) {

    // YOUR CODE GOES HERE
    String period = ".";
    for (int i = 0; i < letters.length(); i++) {
      String ithLetter = letters.substring(i, i + 1);
      if(!ithLetter.equals(period)){
        for (int j = 0; j < wordList.size(); j++) {
                 if (wordList.get(j).indexOf(ithLetter) == -1 || wordList.get(j).substring(i,i+1).equals(ithLetter)){
                 wordList.remove(j);
                 j--;
          }
        }
      }
  }
  }

  // Part C ... Part C
  // Remove words from wordList according to Yellow letter rules
  // Precondition: letters.length() == 5 and
  // letters only contains uppercase letters and '.'
  public void removeWordsGreenLetters(String letters) {

    // YOUR CODE GOES HERE
    String period = ".";
    for (int i = 0; i < letters.length(); i++) {
      String ithLetter = letters.substring(i, i + 1);
      if(!ithLetter.equals(period)){
        for (int j = 0; j < wordList.size(); j++) {
                 if (!wordList.get(j).substring(i,i+1).equals(ithLetter)){
                 wordList.remove(j);
                 j--;
          }         

        }
    }
    }

  }

  // ~~~~~~~~~~~~~~~~~~~ DO NOT MO6DIFY BELOW THIS LINE ~~~~~~~~~~~~~~~~~~~
  // ~~~~~~~~~~~~~~~~~~~ DO NOT MODIFY BELOW THIS LINE ~~~~~~~~~~~~~~~~~~~
  // ~~~~~~~~~~~~~~~~~~~ DO NOT MODIFY BELOW THIS LINE ~~~~~~~~~~~~~~~~~~~
  // ~~~~~~~~~~~~~~~~~~~ DO NOT MODIFY BELOW THIS LINE ~~~~~~~~~~~~~~~~~~~
  public WordleSolver() {
    wordList = new ArrayList<String>();
    readWordsFromFile();
  }

  public ArrayList<String> getWordList() {
    return wordList;
  }

  public void readWordsFromFile() {
    BufferedReader reader;
    try {
      reader = new BufferedReader(new FileReader("./wordfile.txt"));
      String line = reader.readLine();
      while (line != null) {
        wordList.add(line.trim());
        line = reader.readLine();
      }
      reader.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}