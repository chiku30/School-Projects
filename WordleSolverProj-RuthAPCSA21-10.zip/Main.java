import java.util.ArrayList;
import java.util.Scanner;

//instantiates a WordleSolver object
// and invokes methods to help solve a Wordle

class Main {
  public static void main(String[] args) {
    WordleSolver ws = new WordleSolver();
    Scanner console = new Scanner(System.in);
    ArrayList<String>words = ws.getWordList();

    String input = "";
    int attempts = 6;
    for (int k = 1; k <= attempts; k++) {
      System.out.println("There are " + words.size() + " left.\n");

      System.out.println("Attempt #" + k);
      System.out.println("Type up to 5 letters that are shown in Gray: ");
      input = console.nextLine();
      ws.removeWordsGrayLetters(input);
      System.out.println("There are " + words.size() + " left.\n");
      System.out.println("Type exacly 5 characters for the letters in Yellow: ");
      //System.out.println(words);
      input = console.nextLine();
      ws.removeWordsYellowLetters(input);
      System.out.println("There are " + words.size() + " left.\n");
      //System.out.println(words);
      System.out.println("Type exacly 5 charactANIMers for the letters in Green: ");
      input = console.nextLine();
      ws.removeWordsGreenLetters(input);
      System.out.println(words);
    }
  }
}