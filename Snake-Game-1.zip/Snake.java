import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

class Snake {
/**
* Current direction of the Snake will always be either 8, 2, 4, or 6 … which is
* up, down, left, right taken from the orientation of numpad keys on keyboard
*/
private int currentDirection = 8;

/** The number of tail pieces that need to be added to the end of body */
private int amountToGrow = 5;

/** The head of the Snake */
private Rectangle head;

/** The List of Rectangle objects that are the body of the Snake */
private ArrayList<Rectangle> body;

/**
* The List of integer directions stored from keyboard input that the Snake will
* turn based on the order in which they were inputted from the keyboard
*/
private ArrayList<Integer> directionQ;

/** The object the Snake will intersect with to grow */
// private Rectangle nibble = new Rectangle(200, 300, 20, 20);

private int playerNum;
private int score;

public Snake(int curDir, int amtGro, int pNum) {
/* to be implemented in Question 1 part (a) */
playerNum = pNum;
if (playerNum == 1) {
head = new Rectangle(200, 200, 20, 20);
} else {
head = new Rectangle(800, 200, 20, 20);
}
// nibble = new Rectangle(200, 300, 20, 20);
body = new ArrayList<Rectangle>();
directionQ = new ArrayList<Integer>();
currentDirection = curDir;
amountToGrow = amtGro;

}

public void render(Graphics2D g) {
/* to be implemented in Question 1 part (b) */
//Color snakeColor1 = new Color(60, 18, 37);
Color snakeColor1 = new Color(221, 161, 94);
Color snakeColor2 = new Color(96, 108, 56);
Color snakeBody1 = new Color(254, 255, 173);
Color snakeBody2 = new Color(215, 255, 171);
//(199,168,173)

// g.setColor(new Color (140, 70, 90));
// g.setColor(Color.RED);
g.fill(head);
g.setColor(new Color(96, 108, 56));
// g.draw(body);
// g.setColor(new Color (96, 108, 56));
// g.fill(nibble);
if (playerNum == 1) {
g.setColor(snakeColor1);
g.draw(head);
g.fill(head);
}
g.setColor(Color.RED);

if (playerNum == 2) {
g.setColor(snakeColor2);
g.draw(head);
g.fill(head);
}
g.setColor(Color.RED);
g.draw(SnakeGameAAD.gameArea);

if (playerNum == 1) {
g.setColor(snakeBody1);
}
if (playerNum == 2) {
g.setColor(snakeBody2);
}

for (Rectangle r : body) {
g.draw(r);
g.fill(r);

}

}

public void addDirection(int d) {
/* to be implemented in Question 2 part (a) */
if ((directionQ.size() == 0) && ((d != currentDirection) && (d + currentDirection != 10))) {
directionQ.add(d);
} else {
directionQ.add(d);
}
/*
* OLD CODE if ((directionQ.size() == 0) && ((d != 2 && d != 8) || (d != 4 && d
* !=6))){ directionQ.add(d); } if(directionQ.size() == 0 &&
* ((d!=curDir)d!=-curDir))
*/
}

public void updateDirection() {
/* to be implemented in Question 2 part (b) */
if (directionQ.size() != 0) {
currentDirection = directionQ.get(0);
directionQ.remove(0);
}
}

public void updatePosition() {
/* to be implemented in Question 2 part (c) */
body.add(0, new Rectangle(head));

if (currentDirection == 8) {
head.translate(0, -head.width);
}
if (currentDirection == 2) {
head.translate(0, head.width);
}
if (currentDirection == 6) {
head.translate(head.width, 0);
}
if (currentDirection == 4) {
head.translate(-head.width, 0);
}
}

/*
* public void moveNibble() { //* to be implemented in Question 3 part (a) //
* for(Rectangle r: body) { nibble.x = ((int) (Math.random() *
* (SnakeGameAAD.resolution.x / head.width))) * head.width; nibble.y = ((int)
* (Math.random() * (SnakeGameAAD.resolution.y / head.width))) * head.width;
*
* if (nibble.intersects(r)) { moveNibble(); } }
*
* }
*/

/*
* int screenWidth = 400; int tempx = (int)(Math.random() * (screenWidth /
* head.width)); tempx *= head.width; nibble.x = tempx; int tempy =
* (int)(Math.random() * (screenWidth / head.length)); tempy *= head.length;
* nibble.y = tempy;
*/

public boolean eatNibble(Nibble n) {
// to be implemented in Question 3 part (b)
if (head.intersects(n.getNibble())) {
amountToGrow += 5;
n.moveNibble(this);
score++;


return true;
}
return false;
}

public boolean hitRock(Rock r) {
if (head.intersects(r.getRock())) {
amountToGrow -= 10;
r.moveRock(this);

return true;
}
return false;
}


public int getScore() {
return score;
}



public Rectangle getHead() {
return head;
}

public ArrayList<Rectangle> getBody() {
return body;
}

public void eraseTail() {
/* to be implemented in Question 3 part (c) */
if (amountToGrow == 0) {
int last = body.size() - 1;
body.remove(last);
} else {
amountToGrow--;
}
}

/*
* public int highScore(Nibble nib) { hs = highScore; if (nib.eatNibble()) {
* hs++; } break; }
*/

public boolean isDead() {
/* to be implemented in Question 4 part (a) */
for (int i = 0; i < body.size(); i++) {
if (head.intersects(body.get(i))) {
return true;
}
}
if (!head.intersects(SnakeGameAAD.gameArea)) {
return true;
}
return false;
}
}// end class Snake
