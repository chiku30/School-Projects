import java.awt.*;

public class Rock {
  private Rectangle rock = new Rectangle(500, 250, 40, 20);

  public Rock() {
    rock = new Rectangle(500, 250, 40, 20);
  }

  public void render(Graphics2D g) {
    g.setColor(Color.GRAY);
    // g.draw(nibble);
    g.fill(rock);
  }

  public void moveRock(Snake s) {
    // for(Rectangle r:body) {

    rock.x = ((int) (Math.random() * (SnakeGameAAD.resolution.x / s.getHead().width))) * s.getHead().width;
    rock.y = ((int) (Math.random() * (SnakeGameAAD.resolution.y / s.getHead().width))) * s.getHead().width;
    rock.width = ((int) (Math.random() * 50));
    rock.height = ((int) (Math.random() * 50));

    // }
  }

  public Rectangle getRock() {
    return rock;
  }
}