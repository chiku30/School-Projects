/*
import java.awt.*;
import javax.swing.*;
import javax.swing.border.Border;
*/


import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;


public class SnakeGameAAD extends JPanel implements KeyListener, ActionListener {

// ~~~~~~~~~~~~~~~~~~~~~~~~~~
// UNCOMMENT after Question 1
private Snake snake = new Snake(2, 5, 1);
private Snake snake2 = new Snake(10, 25, 2);

// UNCOMMENT after Question 1
// ~~~~~~~~~~~~~~~~~~~~~~~~~~

private int frameCount;
private Timer timer;
private Image offScreenBuffer;// double buffering
private Graphics offScreenGraphics;// double buffering
private Nibble nibble;
private Rock rock = new Rock();




//public static Point resolution = new Point(1280, 1024);
public static Point resolution = new Point(800, 600);
// public static Point resolution = new Point(1280, 1024);
public static Rectangle gameArea = new Rectangle(0, 0, resolution.x - 1, resolution.y - 1);
public static int dim = 30;

/**
* initializes all fields needed for each round of play (i.e. restart)
*/
public void initRound() {
frameCount = 0;

// ~~~~~~~~~~~~~~~~~~~~~~~~~~
// UNCOMMENT after Question 1
snake = new Snake(6, 3, 1);
snake2 = new Snake(4, 3, 2);
nibble = new Nibble();
rock = new Rock();
// UNCOMMENT after Question 1
// ~~~~~~~~~~~~~~~~~~~~~~~~~~

}

/**
* renders all objects to Graphics g (i.e. the window)
*/



public void draw(Graphics2D g) {
if (g == null)
return;
super.paint(g);// refresh the background
g.setColor(Color.BLACK);
g.drawString("Player 1", (SnakeGameAAD.resolution.x / 2) - 250 , 70);
g.drawString(snake.getScore() + "    ", (SnakeGameAAD.resolution.x / 2) - 230 , 90);


g.drawString("Player 2" + "        ", (SnakeGameAAD.resolution.x / 2) + 150 , 70);
g.drawString(snake2.getScore() + "    ", (SnakeGameAAD.resolution.x / 2) + 170 , 90);


//g.drawString("frameCount: " + frameCount, 40, 40);

if (timer != null &&!timer.isRunning()) {
g.drawString("PRESS SPACE TO START", (SnakeGameAAD.resolution.x / 2) -75, (SnakeGameAAD.resolution.y / 2) - 75);
// g.drawString("PRESS SPACE TO START, (SnakeGameAAD.resolution.x / 2),
// (SnakeGameAAD.resolution.y / 2));
}


// ~~~~~~~~~~~~~~~~~~~~~~~~~~
// UNCOMMENT after Question 1
snake.render(g);
snake2.render(g);
nibble.render(g);
rock.render(g);
// UNCOMMENT after Question 1
// ~~~~~~~~~~~~~~~~~~~~~~~~~~

}

/**
* Update all game objects .. called automatically when the timer fires<br>
*/
public void actionPerformed(ActionEvent e) {

// ~~~~~~~~~~~~~~~~~~~~~~~~~~
// UNCOMMENT after Question 2
snake.updateDirection();
snake.updatePosition();
snake2.updateDirection();
snake2.updatePosition();
// UNCOMMENT after Question 2
// ~~~~~~~~~~~~~~~~~~~~~~~~~~

// ~~~~~~~~~~~~~~~~~~~~~~~~~~
// UNCOMMENT after Question 3

snake.eatNibble(nibble);
snake2.eatNibble(nibble);
snake.hitRock(rock);
snake2.hitRock(rock);
snake.eraseTail();
snake2.eraseTail();
// UNCOMMENT after Question 3
// ~~~~~~~~~~~~~~~~~~~~~~~~~~

// ~~~~~~~~~~~~~~~~~~~~~~~~~~
// UNCOMMENT after Question 4
if (snake.isDead())
timer.stop();

if (snake2.isDead())
timer.stop();
// UNCOMMENT after Question 4
// ~~~~~~~~~~~~~~~~~~~~~~~~~~

frameCount++;// keep track of how many frames in the round
repaint();// needed to refresh the animation
}

/**
* handles key pressed events and updates the snake's direction
*/
public void keyPressed(KeyEvent e) {
int keyCode = e.getKeyCode();

// ~~~~~~~~~~~~~~~~~~~~~~~~~~
// UNCOMMENT after Question 2
if (keyCode == KeyEvent.VK_UP)
snake2.addDirection(8);
else if (keyCode == KeyEvent.VK_DOWN)
snake2.addDirection(2);
else if (keyCode == KeyEvent.VK_LEFT)
snake2.addDirection(4);
else if (keyCode == KeyEvent.VK_RIGHT)
snake2.addDirection(6);

if (keyCode == KeyEvent.VK_R)
snake.addDirection(8);
else if (keyCode == KeyEvent.VK_F)
snake.addDirection(2);
else if (keyCode == KeyEvent.VK_D)
snake.addDirection(4);
else if (keyCode == KeyEvent.VK_G)
snake.addDirection(6);
// UNCOMMENT after Question 2
// ~~~~~~~~~~~~~~~~~~~~~~~~~~

}

/**
* handles key released events and restarts the game on 'space' event
*/
public void keyReleased(KeyEvent e) {
int keyCode = e.getKeyCode();
if (keyCode == KeyEvent.VK_SPACE && !timer.isRunning()) {
timer.start();
initRound();
}

if (keyCode == KeyEvent.VK_ESCAPE || keyCode == KeyEvent.VK_W) {
System.exit(0);
}

}

/**
* you should write all necessary initialization code in initRound() THIS METHOD
* SHOULD ONLY BE MODIFIED IF ADDING SOUNDS OR IMAGES! .. <br>
*/
public void init() {
offScreenBuffer = createImage(getWidth(), getHeight());// should be 400x400
offScreenGraphics = offScreenBuffer.getGraphics();
initRound();
timer = new Timer(100, this);
// timer fires every 100 milliseconds.. and invokes method actionPerformed()
}

/**
* main method needed for initialize the game window .. <br>
* THIS METHOD SHOULD NOT BE MODIFIED! .. <br>
*/
public static void main(String[] args) {
JFrame window = new JFrame("Snake Game Clone");
window.setBounds(0, 0, resolution.x, resolution.y);
window.setUndecorated(true);
// window.setBounds(100, 100, 400 + 6, 400 + 28);// inside JFrame will be
// 600x600
window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
window.setResizable(false);

try {
SnakeGameAAD game = new SnakeGameAAD();
//Color backColor = new Color(157, 197, 187);
//Color backColor = Color.BLACK;
Color backColor = new Color(241,227, 228);
//Color backColor = new Color(247,231, 152);
game.setBackground(backColor);
// game.setBackground(Color.WHITE);
window.getContentPane().add(game);
window.setVisible(true);
game.init();
window.addKeyListener(game);
} catch (Exception e) {
// TODO Auto-generated catch block
e.printStackTrace();
System.exit(0);
}
}

/**
* Called automatically after a repaint request<br>
* .. THIS METHOD SHOULD NOT BE MODIFIED! .. <br>
*/
public void paint(Graphics g) {
draw((Graphics2D) offScreenGraphics);
g.drawImage(offScreenBuffer, 0, 0, this);
}

/**
* leave empty.. needed for implementing interface KeyListener<br>
* .. THIS METHOD SHOULD NOT BE MODIFIED! .. <br>
*/
public void keyTyped(KeyEvent e) {
}
}// end class SnakeGameAAD
