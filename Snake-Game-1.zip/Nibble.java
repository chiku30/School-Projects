import java.awt.*;

public class Nibble {
private Rectangle nibble = new Rectangle(200, 300, 20, 20);

public Nibble() {
nibble = new Rectangle(200, 300, 20, 20);
}

public void render(Graphics2D g) {
g.setColor(new Color(169, 35, 50));
//g.draw(nibble);
g.fill(nibble);
}

public void moveNibble(Snake s) {
//for(Rectangle r:body) {

nibble.x = ((int) (Math.random() * (SnakeGameAAD.resolution.x / s.getHead().width))) * s.getHead().width;
nibble.y = ((int) (Math.random() * (SnakeGameAAD.resolution.y / s.getHead().width))) * s.getHead().width;
//}
}


public  Rectangle getNibble() {
return nibble;
}
}
